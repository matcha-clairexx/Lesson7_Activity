# Lesson 7 Activity - Write a Test Suite for the Student Manager

A single-file solution based on the Laravel Testing Applications lesson. It covers factories, authentication, validation, authorization, the Sanctum API, and the slide 16 quick-check questions.

> **Before running tests:** This solution assumes the Lesson 6 Laravel app has `/students` web routes, a student update policy, and a Sanctum-protected `/api/students` endpoint. Check `phpunit.xml` and make sure its `DB_` settings point to a test database, never your real student database.

## 1. Create factories and the test file

Run these commands in the Laravel application:

```bash
php artisan make:factory CourseFactory
php artisan make:factory StudentFactory
php artisan make:test StudentTest
```

Add Laravel's `HasFactory` trait to both the `Course` and `Student` models:

```php
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Student extends Model
{
    use HasFactory;

    // Keep the rest of the existing model code.
}
```

### `database/factories/CourseFactory.php`

```php
<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class CourseFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake()->words(2, true),
        ];
    }
}
```

### `database/factories/StudentFactory.php`

```php
<?php

namespace Database\Factories;

use App\Models\Course;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class StudentFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'course_id' => Course::factory(),
            'user_id' => User::factory(),
        ];
    }
}
```

## 2. Add feature tests

Put these Pest tests in `tests/Feature/StudentTest.php`. `RefreshDatabase` isolates each test's database changes.

```php
<?php

use App\Models\Course;
use App\Models\Student;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;

pest()->use(RefreshDatabase::class);

test('guests are redirected to login', function () {
    $this->get('/students')
        ->assertRedirect('/login');
});

test('logged-in users can view the student list', function () {
    $this->actingAs(User::factory()->create())
        ->get('/students')
        ->assertOk();
});

test('email is required when creating a student', function () {
    $this->actingAs(User::factory()->create())
        ->post('/students', [
            'name' => 'Ana',
            'email' => '',
        ])
        ->assertSessionHasErrors(['email']);
});

test('a valid student is saved', function () {
    $user = User::factory()->create();
    $course = Course::factory()->create();

    $this->actingAs($user)->post('/students', [
        'name' => 'Ana',
        'email' => 'ana@example.com',
        'course_id' => $course->id,
    ]);

    $this->assertDatabaseHas('students', [
        'email' => 'ana@example.com',
        'course_id' => $course->id,
    ]);
});

test('a stranger cannot update another users student', function () {
    $student = Student::factory()->create();
    $stranger = User::factory()->create();

    $this->actingAs($stranger)
        ->put("/students/{$student->id}", [
            'name' => 'Changed by stranger',
        ])
        ->assertForbidden();

    $this->assertDatabaseMissing('students', [
        'id' => $student->id,
        'name' => 'Changed by stranger',
    ]);
});

test('the owner can update their student', function () {
    $owner = User::factory()->create();
    $student = Student::factory()->create([
        'user_id' => $owner->id,
    ]);

    $this->actingAs($owner)
        ->put("/students/{$student->id}", [
            'name' => 'Updated student',
            'email' => $student->email,
            'course_id' => $student->course_id,
        ])
        ->assertRedirect();

    $this->assertDatabaseHas('students', [
        'id' => $student->id,
        'name' => 'Updated student',
    ]);
});

test('the students API requires a token', function () {
    $this->getJson('/api/students')
        ->assertUnauthorized();
});

test('the API returns shaped paginated students with a token', function () {
    $user = User::factory()->create();

    Sanctum::actingAs($user);

    Student::factory()
        ->count(3)
        ->create(['user_id' => $user->id]);

    $this->getJson('/api/students')
        ->assertOk()
        ->assertJsonStructure([
            'data' => [[
                'id',
                'name',
                'course' => ['id', 'name'],
            ]],
            'links' => ['first', 'last', 'prev', 'next'],
            'meta' => ['current_page', 'last_page', 'per_page', 'total'],
        ])
        ->assertJsonMissingPath('data.0.user_id');
});
```

The suite contains eight independent feature tests. Each test builds its own data with factories rather than relying on existing database records.

## 3. Run and verify the tests

```bash
php artisan test
```

All tests should pass. Then temporarily remove the `authorize()` call from the student update action and rerun the suite. The stranger authorization test should fail because a non-owner can update a record. Restore the authorization call after this check.

## Slide 16 quick-check answers

**Q1. Why should most tests be feature tests?**  
Feature tests send requests through the app's routes, middleware, controllers, and database. They verify that those parts work together, rather than only testing an isolated function.

**Q2. What would go wrong without `RefreshDatabase`?**  
Test records could remain in the database or leak between tests. Tests could become order-dependent or fail because of old data instead of the behavior being tested.

**Q3. Why test the stranger case, not just the owner?**  
The owner case proves authorized access works; the stranger case proves the policy blocks unauthorized changes. It detects a missing or broken authorization check.

## Completion checklist

- `php artisan test` passes all eight tests.
- Factories create independent test users, courses, and students.
- Removing the update authorization check causes the stranger test to fail.
- Commit and push the passing tests to the repository.
